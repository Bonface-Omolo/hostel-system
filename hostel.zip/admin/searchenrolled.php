<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.table{
			margin: 10px auto;
			border-collapse: collapse;
			width: 80%;
		}
		.table tr th{
			background-color: dodgerblue;
			color: white;
			padding: 10px;
		}
		.table tr td{
			padding: 5px;
		}
		.table tr:hover{
			background-color: #ccc;
		}
		.center{
			width: 80%;
			margin: 20px auto;
		}
	
	</style>
</head>
<body>

<?php 

require '../dbcontroller.php';
include ('a-header.php');

if (isset($_POST['search'])) {
	$input = mysqli_real_escape_string($con, $_POST['search-input']);

	$searchQuery = mysqli_query($con, "select * from enrollement where fname like '%$input%'  or lname like '%$input%' or email like '%$input%' or contact like '%$input%' or university like '%$input%' or county like '%$input%' or rname like '%$input%'");

		echo "
			<table class='table' border=1>
			<thead>
				<tr>
					<th>NAMES</th>
					<th>EMAIL</th>
					<th>CONTACT</th>
					<th>UNIVERSITY</th>
					<th>COUNTY</th>
					<th>ROOM NAME</th>
				</tr>
			</thead>
			<tbody>
		";

	if (mysqli_num_rows($searchQuery)>0){
		$no =1;
		while ($row = mysqli_fetch_array($searchQuery)) {
			?>
				<tr>
					<form action="action.php" method="post">
				<td><?php echo $row['fname']; ?> <?php echo $row['lname']; ?></td>
				<td><?php echo $row['email']; ?></td>
				<td><?php echo $row['contact']; ?></td>
				<td><?php echo $row['university']; ?></td>
				<td><?php echo $row['county']; ?></td>
				<td><?php echo $row['rname']; ?></td>
					
					</form>
				</tr>
			<?php
				$no ++;
				}
			}echo '</tbody></table>';
	}


?>

</body>
</html>