<!DOCTYPE html>
<html>
<head>
	<title>payment edit</title>
	<style type="text/css">
		.form{
				width: 50%;
				margin: 50px auto;
				border: 1px solid black;
				border-radius: 10px;
				background: #ccc;
				color: black;
				padding: 20px;
				text-align: left;

			}
			form input{
				width: 50%;
				padding: 5px;
				margin: 10px auto;
				margin-left: 25%;
			}
			.btn{
				width: 20%;
				background: dodgerblue;
				color: white;
				border-radius: 7px;
				border: none;
			}
			.btn:hover{
				color: dodgerblue;
				background: white;
				border: 1px dodgerblue solid;
			}
			label{
				margin-left: 25%
			}
	</style>
</head>
<body>

	<?php 

	require '../dbcontroller.php';
	include ('a-header.php');

	error_reporting(0);

	$pID = $_GET['productID'];

	$selectQuery = mysqli_query($con, "select * from payment where id='$pID' ");
	$fetchQuery = mysqli_fetch_array($selectQuery);

	$rname = $fetchQuery['idnumber'];
	$rcode = $fetchQuery['mpesa'];
	$snumber = $fetchQuery['amount'];

	?>

<form method="post" action="" class="form" ><br>
	<label for="fname" >Id number</label>
	<input type="text" name="rname" value="<?php echo $rname?>"><br>
	<label for="fname" >Mpesa code</label> 
	<input type="text" name="rcode" value="<?php echo $rcode ?>"><br>
	<label for="fname" >Amount</label> 
	<input type="text" name="snumber" value="<?php echo $snumber?>"><br>
	<br>

	<input type="submit" name="edit" class="btn" value="Update">
</form>

<?php 

	if (isset($_POST['edit'])) {
		$idnumber = $_POST['idnumber'];
		$mpesa = $_POST['mpesa'];
		$amount = $_POST['amount'];

		$checkQuery = mysqli_query($con, "select * from payment where id='$pID' ");
		$noRow = mysqli_num_rows($checkQuery);

		if ($noRow>0){
			$updateQuery = mysqli_query($con, "update payment set idnumber='$idnumber', mpesa='$mpesa', amount='$amount' where id='$pID'");
			if ($updateQuery) {
				echo "<script>alert('Payment updated successfully'); window.open('view-payment.php','_self') </script>";
			}else{
				echo "<script>alert('failed to update'); window.open('','_self') </script>";
			}

		}
	}

 ?>
 </body>
</html>