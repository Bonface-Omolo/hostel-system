<?php 

require '../dbcontroller.php';

if (isset($_POST['submit'])) {
	$rname = mysqli_real_escape_string($con, $_POST['name']);
	$rcode = mysqli_real_escape_string($con, $_POST['id']);
	$size  = mysqli_real_escape_string($con, $_POST['size']);
	$status = mysqli_real_escape_string($con, $_POST['status']);
	$amount = mysqli_real_escape_string($con, $_POST['amount']);

	    $Check_room = mysqli_query($con, "select * from room where rcode='$rcode'");
	    $check_row = mysqli_num_rows($Check_room);
		if ($check_row==0) {
			$insert_reg = mysqli_query($con, "insert into room(rname, rcode, snumber, status, amount) values('$rname','$rcode','$size','$status','$amount')");
			if ($insert_reg) {echo "<script>alert('data inserted successfully'); window.open('room.php','_self')</script>";
			}else {echo "<script>alert('Insertion failed'); window.open('room.php','_self')</script>";}
		}else {echo "<script>alert('The code already exists'); window.open('room.php','_self')</script>";}
	}
					
?>