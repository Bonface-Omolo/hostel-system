<!DOCTYPE html>
<html>
<head>
	<title>room edit</title>
	<style type="text/css">
		.form{
				width: 50%;
				margin: 50px auto;
				border: 1px solid black;
				border-radius: 10px;
				background: #ccc;
				color: black;
				padding: 20px;
				text-align: left;

			}
			form input{
				width: 50%;
				padding: 5px;
				margin: 10px auto;
				margin-left: 25%;
			}
			.btn{
				width: 20%;
				background: dodgerblue;
				color: white;
				border-radius: 7px;
				border: none;
			}
			.btn:hover{
				color: dodgerblue;
				background: white;
				border: 1px dodgerblue solid;
			}
			label{
				margin-left: 25%
			}
	</style>
</head>
<body>

	<?php 

	require '../dbcontroller.php';
	include ('a-header.php');

	error_reporting(0);

	$pID = $_GET['productID'];

	$selectQuery = mysqli_query($con, "select * from room where id='$pID' ");
	$fetchQuery = mysqli_fetch_array($selectQuery);

	$rname = $fetchQuery['rname'];
	$rcode = $fetchQuery['rcode'];
	$snumber = $fetchQuery['snumber'];
	$status = $fetchQuery['status'];
	$amount = $fetchQuery['amount'];

	?>

<form method="post" action="" class="form" ><br>
	<label for="fname" >Room Name</label>
	<input type="text" name="rname" value="<?php echo $rname?>"><br>
	<label for="fname" >Room Number</label> 
	<input type="text" name="rcode" value="<?php echo $rcode ?>"><br>
	<label for="fname" >Size Number</label> 
	<input type="text" name="snumber" value="<?php echo $snumber?>"><br>
	<label for="fname" >Status</label> 
	<input type="text" name="status" value="<?php echo $status?>"><br>
	<label for="fname" >Amount</label> 
	<input type="text" name="amount" value="<?php echo $amount ?>"><br>

	<input type="submit" name="edit" class="btn" value="Update">
</form>

<?php 

	if (isset($_POST['edit'])) {
		$rname = $_POST['rname'];
		$rcode = $_POST['rcode'];
		$snumber = $_POST['snumber'];
		$status = $_POST['status'];
		$amount = $_POST['amount'];

		$checkQuery = mysqli_query($con, "select * from room where id='$pID' ");
		$noRow = mysqli_num_rows($checkQuery);

		if ($noRow>0){
			$updateQuery = mysqli_query($con, "update room set rname='$rname', rcode='$rcode', snumber='$snumber', status='$status', amount='$amount' where id='$pID'");
			if ($updateQuery) {
				echo "<script>alert('Room updated successfully'); window.open('view-room.php','_self') </script>";
			}else{
				echo "<script>alert('failed to update'); window.open('','_self') </script>";
			}

		}
	}

 ?>
 </body>
</html>