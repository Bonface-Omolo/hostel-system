<?php 
session_start();
include('admin-session.php'); 
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home | Hostel</title>
</head>
<body style="padding: 0px; margin: 0px;">
<?php include('header.php'); ?><br><br>

<a href="room.php" class='btn'>Add new room</a>
<a href="std-new.php" class='btn'>Add new students</a>
<a href="room.php" class='btn'>View student information</a>
<a href="std-info.php" class='btn'>View Payment information</a>
<a href="std-info.php" class='btn'>view rooms status</a>

</body>
</html>