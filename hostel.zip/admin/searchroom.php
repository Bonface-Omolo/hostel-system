<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.table{
			margin: 10px auto;
			border-collapse: collapse;
			width: 80%;
		}
		.table tr th{
			background-color: dodgerblue;
			color: white;
			padding: 10px;
		}
		.table tr td{
			padding: 5px;
		}
		.table tr:hover{
			background-color: #ccc;
		}
		.center{
			width: 80%;
			margin: 20px auto;
		}
	</style>
</head>
<body>

<?php 

require '../dbcontroller.php';
include ('a-header.php');

if (isset($_POST['search'])) {
	$input = mysqli_real_escape_string($con, $_POST['search-input']);

	$searchQuery = mysqli_query($con, "select * from room where rname like '%$input%'  or rcode like '%$input%' or snumber like '%$input%'  or status like '%$input%' or amount like '%$input%' ");

		echo "
			<table class='table' border=1>
			<thead>
				<tr>
					<th>Room Name</th>
					<th>Room Number</th>
					<th>Size Number</th>
					<th>Status</th>
					<th>Amount</th>
					<th>checklist</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
		";

	if (mysqli_num_rows($searchQuery)>0){
		$no =1;
		while ($row = mysqli_fetch_array($searchQuery)) {
			?>
				<tr>
					<form action="action.php" method="post">
					<td><?php echo $row['rname']; ?> 
					<td><?php echo $row['rcode']; ?></td>
					<td><?php echo $row['snumber']; ?></td>
					<td><?php echo $row['status']; ?></td>
					<td><?php echo $row['amount']; ?></td>
						<td><label><input class="indeterminate-checkbox" type="checkbox" name="check" value="<?php echo $row['p_id']; ?>" required><span></span></label></td>
						<td>
							<a href='room-edit.php?productid=<?php echo $row['id']; ?>' type="submit" name="edit" value="Edit" style="text-decoration:none;padding:3px;border-radius:4px;border:none;background-color:steelblue;color:white">Edit</a>
							<button type="submit" name="delete" value="Delete" style="padding:3px;border-radius:4px;border:none;background-color:red;color:white">Delete</button>
						</td>
					</form>
				</tr>
			<?php
				$no ++;
				}
			}echo '</tbody></table>';
	}


?>
</body>
</html>