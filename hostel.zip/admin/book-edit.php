<?php session_start(); include('admin-session.php'); ?>

<!DOCTYPE html>
<html>
<head>
	<title>book editing</title>
	<style type="text/css">
		.form{
				width: 50%;
				margin: 50px auto;
				border: 1px solid black;
				border-radius: 10px;
				background: #ccc;
				color: black;
				padding: 20px;
				text-align: left;

			}
			form input{
				width: 50%;
				padding: 5px;
				margin: 10px auto;
				margin-left: 25%;
			}
			.btn{
				width: 20%;
				background: dodgerblue;
				color: white;
				border-radius: 7px;
				border: none;
			}
			.btn:hover{
				color: dodgerblue;
				background: white;
				border: 1px dodgerblue solid;
			}
			label{
				margin-left: 25%



			}
	</style>
</head>
<body>


<?php 

require '../dbcontroller.php';
include ('a-header.php');

error_reporting(0);

$pID = $_GET['productID'];

$selectQuery = mysqli_query($con, "select * from book where id='$pID' ");
$fetchQuery = mysqli_fetch_array($selectQuery);

$idnumber = $fetchQuery['idnumber'];
$fname = $fetchQuery['fname'];
$lname = $fetchQuery['lname'];
$contact = $fetchQuery['contact'];
$rname = $fetchQuery['rname'];
$date = $fetchQuery['date'];
$payment = $fetchQuery['payment'];


?>

<form method="post" action="" class="form" ><br>
	<label for="idnumberd" >Id Number</label> 
	<input type="text" name="idnumber" value="<?php echo $idnumber?>"><br>
	<label for="fname" >First Name</label> 
	<input type="text" name="fname" value="<?php echo $fname ?>"><br>
	<label for="fname" >Last Namer</label> 
	<input type="text" name="lname" value="<?php echo $lname?>"><br>
	<label for="fname" >Contact</label> 
	<input type="text" name="contact" value="<?php echo $contact?>"><br>
	<label for="fname" >Room Name</label> 
	<input type="text" name="rname" value="<?php echo $rname ?>"><br>
	<label for="fname" >Date</label> 
	<input type="text" name="date" value="<?php echo $date?>"><br>
	<label for="fname" >Mode of Payment</label> 
	<input type="text" name="payment" value="<?php echo $payment ?>"><br>

	<input type="submit" name="edit" class="btn" value="Update">
</form>


<?php 

	if (isset($_POST['edit'])) {
		$idnumber = $_POST['idnumber'];
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];
		$contact = $_POST['contact'];
		$rname = $_POST['rname'];
		$date = $_POST['date'];
		$payment = $_POST['payment'];

		$checkQuery = mysqli_query($con, "select * from book where id='$pID' ");
		$noRow = mysqli_num_rows($checkQuery);

		if ($noRow>0){
			$updateQuery = mysqli_query($con, "update book set idnumber='$idnumber', fname='$fname', lname='$lname', contact='$contact', rname='$rname', date='$date' , payment='$payment'  where id='$pID'");
			if ($updateQuery) {
				echo "<script>alert('Booked rooms updated successfully'); window.open('view-booked.php','_self') </script>";
			}else{
				echo "<script>alert('failed to update'); window.open('','_self') </script>";
			}

		}
	}

 ?>
 </body>
</html>