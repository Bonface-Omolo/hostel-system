<?php session_start(); include('admin-session.php'); ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.form{
				width: 50%;
				margin: 50px auto;
				border: 1px solid black;
				border-radius: 10px;
				background: #ccc;
				color: black;
				padding: 20px;
				text-align: left;

			}
			form input{
				width: 50%;
				padding: 5px;
				margin: 10px auto;
				margin-left: 25%;
			}
			.btn{
				width: 20%;
				background: dodgerblue;
				color: white;
				border-radius: 7px;
				border: none;
			}
			.btn:hover{
				color: dodgerblue;
				background: white;
				border: 1px dodgerblue solid;
			}
			label{
				margin-left: 25%



			}
	</style>
</head>
<body>


<?php 

require '../dbcontroller.php';
include ('a-header.php');

error_reporting(0);

$pID = $_GET['productID'];

$selectQuery = mysqli_query($con, "select * from stdsign where id='$pID' ");
$fetchQuery = mysqli_fetch_array($selectQuery);

$fname = $fetchQuery['fname'];
$lname = $fetchQuery['lname'];
$contact = $fetchQuery['contact'];
$email = $fetchQuery['email'];

?>

<form method="post" action="" class="form" ><br>
	<label for="fname" >First Name</label> 
	<input type="text" name="fname" value="<?php echo $fname?>"><br>
	<label for="fname" >Last Name</label> 
	<input type="text" name="lname" value="<?php echo $lname ?>"><br>
	<label for="fname" >Id Number</label> 
	<input type="text" name="contact" value="<?php echo $contact?>"><br>
	<label for="fname" >Email</label> 
	<input type="text" name="email" value="<?php echo $email ?>"><br>

	<input type="submit" name="edit" class="btn" value="Update">
</form>


<?php 

	if (isset($_POST['edit'])) {
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];
		$contact = $_POST['contact'];
		$email = $_POST['email'];

		$checkQuery = mysqli_query($con, "select * from stdsign where id='$pID' ");
		$noRow = mysqli_num_rows($checkQuery);

		if ($noRow>0){
			$updateQuery = mysqli_query($con, "update stdsign set fname='$fname', lname='$lname', contact='$contact', email='$email' where id='$pID'");
			if ($updateQuery) {
				echo "<script>alert('The row updated successfully'); window.open('admin-home.php','_self') </script>";
			}else{
				echo "<script>alert('failed to update'); window.open('','_self') </script>";
			}

		}
	}

 ?>
 </body>
</html>