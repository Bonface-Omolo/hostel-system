
<?php 
session_start();
include('hostel-session.php'); 
?>

<!DOCTYPE html>
<html>
<head>
	<title>Hosteller Home page</title>
	<style type="text/css">
	
		ul.ul{
			list-style-type: none;
			margin: 0;
			padding: 0;
			width: 25%;
			background-color: #f1f1f1;
			position: fixed;
			height: 100%;
			overflow: auto;
		}
		li a.btn{
			display: block;
			color: #000;
			padding: 20px 0 20px 40px;
			text-decoration: none;
		}
		li a.btn:hover:not(activ){
			background-color: turquoise;
			color: white;
		}
		li a.activ{
			background-color: steelblue;
			color: white;
		}
		.bgsize{
			background-image: url("../image/hostel2.jpg");
			background-size: contain;
			width: 1100px;
			height: 470px;
			border: 1px solid block;
			color: pink;
			resize: both;
			overflow: scroll;
		}
	</style>
</head>
<body>
	<div class="bgsize" >

<?php include('h-header.php'); ?>

	<ul class="ul" >
		<li><a class="btn" href="room.php">Add new room</a></li>
		<li><a class="btn" href="std-new.php" >Enroll New Students</a></li>
		<li><a class="btn" href="view-enrolled.php">View enrolled students</a></li>
		<li><a class="btn" href="view-booked.php">View booked rooms</a></li>
		<li><a class="btn" href="view-payment.php">View payments</a></li>
		<li><a class="btn" href="view-room.php">view rooms status</a></li>
	</ul>
	
		
	</div>

</body>
</html>