<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.table{
			margin: 10px auto;
			border-collapse: collapse;
			width: 80%;
		}
		.table tr th{
			background-color: dodgerblue;
			color: white;
			padding: 10px;
		}
		.table tr td{
			padding: 5px;
		}
		.table tr:hover{
			background-color: #ccc;
		}
		.center{
			width: 80%;
			margin: 20px auto;
		}
	
	</style>
</head>
<body>
<?php 

require '../dbcontroller.php';
include ('h-header.php');

if (isset($_POST['search'])) {
	$input = mysqli_real_escape_string($con, $_POST['search-input']);

	$searchQuery = mysqli_query($con, "select * from book where idnumber like '%$input%'  or fname like '%$input%' or lname like '%$input%' or contact like '%$input%' or rname like '%$input%' or amount like '%$input%' or date like '%$input%'  or payment like '%$input%'");

		echo "
			<table class='table' border=1>
			<thead>
				<tr>
					<th>Id Number</th>
					<th>Occupants</th>
					<th>Contact</th>
					<th>Room Name</th>
					<th>Amount</th>
					<th>date</th>
					<th>Payment Mode</th>
					
				</tr>
			</thead>
			<tbody>
		";

	if (mysqli_num_rows($searchQuery)>0){
		$no =1;
		while ($row = mysqli_fetch_array($searchQuery)) {
			?>
				<tr>
					<form action="" method="post">
						<td><?php echo $row['idnumber']; ?>
						<td><?php echo $row['fname']; ?> <?php echo $row['lname']; ?></td>
						<td><?php echo $row['contact']; ?></td>
						<td><?php echo $row['rname']; ?></td>
						<td><?php echo $row['amount']; ?></td>
						<td><?php echo $row['date']; ?></td>
						<td><?php echo $row['payment']; ?></td>
					
					</form>
				</tr>
			<?php
				$no ++;
				}
			}echo '</tbody></table>';
	}


?>
</body>
</html>