<?php 

require '../dbcontroller.php';

if (isset($_POST['enroll'])) {
	$fname = mysqli_real_escape_string($con, $_POST['fname']);
	$lname = mysqli_real_escape_string($con, $_POST['lname']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$contact = mysqli_real_escape_string($con, $_POST['contact']);
	$university = mysqli_real_escape_string($con, $_POST['university']);
	$county = mysqli_real_escape_string($con, $_POST['county']);
	$rname= mysqli_real_escape_string($con, $_POST['rname']);


	  $Check_enrollement= mysqli_query($con, "select * from enrollement where contact='$contact'");
	    $check_row = mysqli_num_rows($Check_enrollement);
		if ($check_row==0) {
			$insert_reg = mysqli_query($con, "insert into enrollement(fname, lname, email, contact, university, county, rname) values('$fname','$lname','$email','$contact','$university','$county','$rname')");
			if ($insert_reg) {echo "<script>alert('Student enrolled successfully'); window.open('std-new.php','_self')</script>";
			}else {echo "<script>alert('Insertion failed'); window.open('std-new.php','_self')</script>";}
		}else {echo "<script>alert('The contact already exists'); window.open('std-new.php','_self')</script>";}
	}

?>

