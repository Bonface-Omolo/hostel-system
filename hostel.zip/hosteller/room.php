<?php 
session_start();
include('hostel-session.php'); 
require '../dbcontroller.php';
include('h-header.php');
 ?>

<!DOCTYPE html>
	
<head>
<title>Room</title>
<style type="text/css">
	form{
		 width: 60%;
		margin: 2px auto;
		border-radius: 10px;
		background: white;
		color: black;
		padding: 2px;
		text-align: justify;
	}
	input[type=text]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 8px;
		font-size: 16px;


	}
	input[type=number]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;
		font-size: 16px;


	}
	input[type=submit]{
		size: 20px;
		background-color: #4CAF50;
		border: 2px solid black;
		padding: 5px 25px;
		text-decoration: none;
		margin: 2px 2px;
		cursor: pointer;
		border-radius: 6px;
		text-align: center;
		font-size: 16px;
	}
	button[type=cancel]{
		size: 20px;
		background-color: #FFA500;
		border: 2px solid black;
		padding: 5px 25px;
		text-decoration: none;
		margin: 2px 2px;
		cursor: pointer;
		border-radius: 20px;
	}
	 label{
	 	
	}
	h2{
		padding: 2px;
		margin: 2px;
		text-align: center;
	}
</style>
</head>
<body>

<form name="frmRegistration" method="post" action="rom.php" > 
	<h2>Room Information Form</h2>


<label for="rname" >Room name</label><br> 
<input type="text" class="name" name="name" required><br>
<label for="floor" >Room ID</label><br> 
<input type="text" class="id" name="id"  required><br>
<label for="siz" >Sharing Number</label><br>
<input type="number" class="sharing" name="size" required><br>
<label for="status" >Status</label><br> 
<input type="text" class="state" name="status" required><br>
<label for="Amount" >Amount</label><br> 
<input type="text" class="amount" name="amount" required><br>


<input type="submit" name="submit" value="ADD ROOM" class="btn-in">
</form>

</bod/>
</html>
