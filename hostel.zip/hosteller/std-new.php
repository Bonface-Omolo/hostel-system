<?php 
session_start();
include('hostel-session.php'); 
require '../dbcontroller.php'; 
include('h-header.php');
?>

<!DOCTYPE html>
	
<head>
<title>New student</title>
<<style type="text/css">
	form{
		 width: 60%;
		margin: 2px auto;
		border-radius: 10px;
		background: white;
		color: black;
		padding: 2px;
		text-align: justify;
	}
	input[type=text]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;
		font-size: 16px;


	}
	input[type=number]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;
		font-size: 16px;


	}
	input[type=email]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;
		font-size: 16px;


	}
	input[type=password]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;
		font-size: 16px;


	}
	input[type=submit]{
		size: 20px;
		background-color: #4CAF50;
		border: 2px solid black;
		padding: 5px 25px;
		text-decoration: none;
		margin: 2px 2px;
		cursor: pointer;
		border-radius: 8px;
		text-align: center;
	}
	button[type=cancel]{
		size: 20px;
		background-color: #FFA500;
		border: 2px solid black;
		padding: 5px 25px;
		text-decoration: none;
		margin: 2px 2px;
		cursor: pointer;
		border-radius: 20px;
	}
	 label{
	 	
	}
	h2{
		padding: 2px;
		margin: 2px;
		text-align: center;
	}
</style>
</head>
<body style="padding: 0px; margin: 0px;">
<form name="frmRegistration" method="post" action="regi.php"> 
	<h2>Enrolement Form</h2>
<br><br>
<label for="fname" >First Name</label><br>
<input type="text" class="demoInputBox" name="fname" required><br>
<label for="lname" >Last Name</label><br>
<input type="text" class="demoInputBox" name="lname" required><br>
<label for="email" >Email</label><br>
<input type="email" class="demoInputBox" name="email" required><br>
<label for="contact" >Contact</label><br>
<input type="number" class="demoInputBox" name="contact" required><br>
<label for="university" >University</label><br>
<input type="text" class="demoInputBox" name="university" required><br>
<label for="county" >County</label><br>
<input type="text" class="demoInputBox" name="county" required><br>
<label for="county" >Room Name</label><br>
<input type="text" class="demoInputBox" name="rname" required><br>
 <input type="submit"  class='btnRegister' name="enroll" value="Submit" required>
</form>
</bod/>
</html>
