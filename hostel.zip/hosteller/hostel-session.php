<?php 

if (!isset($_SESSION['email'])) {
	header('Location: hostellerlogin.php');
}



 ?>