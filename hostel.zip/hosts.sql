-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2020 at 12:09 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hosts`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(15) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `idnumber` int(10) NOT NULL,
  `contact` int(15) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(50) NOT NULL,
  `cpassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fname`, `lname`, `idnumber`, `contact`, `gender`, `email`, `password`, `cpassword`) VALUES
(2, 'Boniface', 'oundo', 5454545, 6424387, 'Male', 'hyline@boni.com', '09876543', '09876543'),
(7, 'hyline', 'Otieno', 23089000, 76475654, 'Female', 'hylinebonface1@gmail.com', '12345678', '12345678'),
(8, 'Benson', 'omwami', 676566666, 75645645, 'mixture', 'omaribonface@gmail.com', '12345678', '12345678'),
(9, 'Bonface', 'Omolo', 389675896, 2147483647, 'Female', 'omari@gmail.com', '12345678', '12345678'),
(10, 'Bonface', 'Omolo', 4545455, 454545454, 'Male', 'omom2@gmail.com', '12345678', '12345678'),
(11, 'hyline', 'otieno', 65635874, 646587358, 'Female', 'hylineotieno@gmail.com', '12345678', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `id` int(15) NOT NULL,
  `idnumber` int(15) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `contact` int(15) NOT NULL,
  `rname` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `payment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `idnumber`, `fname`, `lname`, `contact`, `rname`, `amount`, `date`, `payment`) VALUES
(1, 1212121212, 'bony', 'omar', 898989, 'yellow', '5555', '2020-04-23', 'mpesa'),
(2, 2323232, 'bony', 'omar', 990, 'yellow', '5555', '2020-04-16', 'mpesa'),
(3, 2147483647, 'honry', 'omar', 9876, 'yellow', '9000', '2020-04-17', 'mpesa'),
(4, 3434343, 'bonface', 'omar', 9876, 'yellow', '9000', '2020-04-17', 'mpesa'),
(6, 6767776, 'martine', 'omondi', 7464725, 'blue', '40000', '2020-04-17', 'Cash'),
(8, 999999, 'bony', 'odhiambo', 756565, 'yellow', '70000', '2020-05-22', 'mpesa'),
(9, 23089421, 'Hyline', 'Achieng', 77654554, 'yellow', '40000', '2020-05-13', 'mpesa'),
(10, 23089111, 'Nicholas', 'Otieno', 754432344, 'blue', '20000', '2020-08-22', 'Cash'),
(11, 2308942, 'Bonface', 'Omolo', 642438765, 'yellow', '20000', '2020-06-27', 'Cash'),
(12, 230894233, 'Bonface', 'Ouma', 999999, 'blue', '5555', '2020-06-23', 'Cash'),
(13, 9999991, 'Bonface', 'Otieno', 78344444, 'yellow', '40000', '2020-07-29', 'mpesa');

-- --------------------------------------------------------

--
-- Table structure for table `enrollement`
--

CREATE TABLE `enrollement` (
  `id` int(15) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `contact` int(15) NOT NULL,
  `university` varchar(250) NOT NULL,
  `county` varchar(250) NOT NULL,
  `rname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enrollement`
--

INSERT INTO `enrollement` (`id`, `fname`, `lname`, `email`, `contact`, `university`, `county`, `rname`) VALUES
(1, 'Bonface', 'Omolo', 'omollobonface01@gmail.com', 6424387, 'piu', 'busia', 'red'),
(2, 'Bonface', 'Omolo', 'omollobonface01@gmail.com', 12313434, 'piu', 'kiambu', 'yellow'),
(3, 'Flistus', 'Mueni', 'muenifelistus@gmail.com', 74253654, 'Pioneer International University', 'Kitui', 'red'),
(4, 'Bonface', 'Omolo', 'omollobonface01@gmail.com', 76424387, 'kca', 'migori', 'blue'),
(5, 'hyline', 'Omolo', 'omollohyline01@gmail.com', 86424387, 'moi', 'busia', 'red'),
(6, 'Kevin', 'Otieno', 'kevin@gmIL.COM', 78454545, 'Pioneer International University', 'kiambu', 'blue'),
(7, 'George ', 'Oado', 'obado@gmail.com', 32345674, 'pioneer', 'kiambu', '09'),
(8, 'Bonface', 'Omolo', 'wambin@gmail.com', 77878778, 'kca', 'migori', 'blue');

-- --------------------------------------------------------

--
-- Table structure for table `hosteller`
--

CREATE TABLE `hosteller` (
  `id` int(15) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `idnumber` int(10) NOT NULL,
  `contact` int(14) NOT NULL,
  `gender` varchar(15) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(50) NOT NULL,
  `cpassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hosteller`
--

INSERT INTO `hosteller` (`id`, `fname`, `lname`, `idnumber`, `contact`, `gender`, `email`, `password`, `cpassword`) VALUES
(1, 'Bonface', 'Omolo', 43434343, 6424387, 'Male', 'omollobonface01@gmail.com', 'admin1234', 'admin1234'),
(3, 'Pamela', 'Otieno', 2308942, 785433344, 'Female', 'arwa@gmail.com', '12345678', '12345678'),
(6, 'Christine', 'Ouma', 677865496, 75646455, 'Female', 'christine@gmail.com', '12345678', '12345678'),
(7, 'Bonface', 'Omolo', 4554544, 2147483647, 'Female', 'omvu@gmail.com', '12345678', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `idnumber` int(50) NOT NULL,
  `mpesa` varchar(200) NOT NULL,
  `amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `idnumber`, `mpesa`, `amount`) VALUES
(1, 5, 'hvfjhbfht564', 78888),
(2, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(15) NOT NULL,
  `rname` varchar(50) NOT NULL,
  `rcode` varchar(50) NOT NULL,
  `snumber` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `rname`, `rcode`, `snumber`, `status`, `amount`) VALUES
(2, 'red', 'r34', '8', 'occupied', '9000'),
(3, 'white', 'r3443', '9', 'empty', '9000'),
(10, 'blue', 'r333', '9', 'empty', '40000'),
(12, 'blue', 'r3440', '9', 'vacant', '40000'),
(15, 'blue', '144155', '34', 'occupied', '40000'),
(16, 'blue', '144155218', '09', 'vacant', '78888');

-- --------------------------------------------------------

--
-- Table structure for table `stdsign`
--

CREATE TABLE `stdsign` (
  `id` int(15) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `contact` int(15) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(50) NOT NULL,
  `cpassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stdsign`
--

INSERT INTO `stdsign` (`id`, `fname`, `lname`, `contact`, `email`, `password`, `cpassword`) VALUES
(1, 'Bonface', 'Omolo', 6424387, 'omollobonface01@gmail.com', '12345678', '12345678'),
(3, 'Benson', 'Omondi', 7635333, 'omondibenson@gmail.com', '12345678', '12345678'),
(4, 'Kenneth', 'Guru', 75646462, 'gurukenneth@gmail.com', '12345678', '12345678'),
(5, 'hanah', 'kamung', 435245245, 'kamunguhanah@gmail.com', '12345678', '12345678'),
(6, 'Benson', 'Omolo', 111111111, 'devisomolo@gmail.com', '12345678', '12345678'),
(7, 'Pamela', 'Achieng', 76565634, 'pamela@gmail.com', '12345678', '12345678'),
(8, 'Kevin', 'Ouma', 74545554, 'kevin@gmIL.COM', '12345678', '12345678'),
(9, 'Bonface', 'Ouma', 78777787, 'ochieng@gmail.com', '12345678', '12345678');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enrollement`
--
ALTER TABLE `enrollement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hosteller`
--
ALTER TABLE `hosteller`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stdsign`
--
ALTER TABLE `stdsign`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `enrollement`
--
ALTER TABLE `enrollement`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `hosteller`
--
ALTER TABLE `hosteller`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stdsign`
--
ALTER TABLE `stdsign`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
