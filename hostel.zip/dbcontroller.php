<?php 

$con = mysqli_connect('localhost','root','','hosts') or die(mysqli_error($con));

?>