<!DOCTYPE html>
<html>
<head>
	<title>index</title>
	<style type="text/css">
		.bg{
			background-image:  url("image/hostel.jpg");
			background-size: contain;
			width: 1250px;
			height: 510px;
			border: 1px solid block;
			/*color: pink;*/
			resize: both;
			overflow: scroll;
/*			background-repeat: no-repeat;*/
		}
		h2{
			text-align: center;
			color: white;
			font-size: 40px;
			font-family: fantasy;
			font-weight: bold;
		}
		h3{
			text-align: center;
			color: white;
			font-size: 30px;
			font-family: verdana;
			font-weight: italic;

		}
	</style>
</head>
<body>
	<?php include('i-header.php'); ?>
<div class="bg" >
		 <h2>  <i>WELCOME TO KIVU HOSTEL MANAGEMENT INFORMATION SYSTEM</i> </h2>
		 <h3> We offer the best services for our customers</h3>
		
	</div>

</body>
</html>