<?php

date_default_timezone_set('Africa/Nairobi');


$con = mysqli_connect('localhost','root','','lians');

