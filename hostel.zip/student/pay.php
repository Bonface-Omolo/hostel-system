<?php 

require '../dbcontroller.php';

if (isset($_POST['payment'])) {
	$idnumber = mysqli_real_escape_string($con, $_POST['idnumber']);
	$mpesa = mysqli_real_escape_string($con, $_POST['mpesa']);
	$amount = mysqli_real_escape_string($con, $_POST['amount']);


	 $Check_book = mysqli_query($con, "select * from payment where mpesa='$mpesa'");
	    $check_row = mysqli_num_rows($Check_book);
		if ($check_row==0) {
			$insert_reg = mysqli_query($con, "insert into payment(idnumber, mpesa, amount) values('$idnumber','$mpesa','$amount')");
			if ($insert_reg) {echo "<script>alert('Payment made successfully'); window.open('payment.php','_self')</script>";
			}else {echo "<script>alert('Insertion failed'); window.open('payment.php','_self')</script>";}
		}else {echo "<script>alert('The mpesa code already exists'); window.open('payment.php','_self')</script>";}
	}
			



?>

