<?php require '../dbcontroller.php'; ?>

<!DOCTYPE html>
	
<head>
<title>PHP User Registration Form</title>
<style type="text/css">
	form{
		 width: 60%;
		margin: 2px auto;
		border-radius: 10px;
		background: white;
		color: black;
		padding: 2px;
		text-align: justify;
	}
	input[type=text]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;


	}
	input[type=number]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;


	}
	input[type=email]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;

	}
	input[type=password]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;


	}
	input[type=submit]{
		size: 20px;
		background-color: #4CAF50;
		border: 2px solid black;
		padding: 5px 25px;
		text-decoration: none;
		margin: 2px 2px;
		cursor: pointer;
		border-radius: 20px;
		text-align: center;
	}
	button[type=cancel]{
		size: 20px;
		background-color: #FFA500;
		border: 2px solid black;
		padding: 5px 25px;
		text-decoration: none;
		margin: 2px 2px;
		cursor: pointer;
		border-radius: 20px;
	}
	 label{
	 	
	}
	h2{
		padding: 2px;
		margin: 2px;
		text-align: center;
	}
	
		header{
				width: 100%;
				position: fixed;
				position: relative;
				height: 100px;
				background: dodgerblue;
			}
			.logo{
				position: absolute;
				left: 10%;
				top: 10px;
			}
			nav{
				position: absolute;
				top: 20px;
				right: 10%;
			}
			nav ul li{
				list-style: none;
				float: left;
			}
			nav ul li a{
				text-decoration: none;
				padding: 20px;
				color: white;
			}
			nav ul li a:hover{
				color: #ccc;
				font-size: 20px;
			}
			h1{
				font-size: 18px;
				padding: 20px;
			}
</style>
</head>
<body>
	<header>
	<div class="logo">
		<h1>KIVU HOSTEL MANAGEMENT INFORMATION SYSTEM</h1>
	</div>
	<nav>
		<ul>
			<li><a href="student-login.php">LOGIN</a></li>
			<li><a href="std-sign.php">SIGN-IN</a></li>
		</ul>
	</nav>
</header>
<form name="frmRegistration" method="post" action="regi.php"> 
<?php if(!empty($success_message)) { ?>	
<div class="success-message"><?php if(isset($success_message)) echo $success_message; ?></div>
<?php } ?>
<?php if(!empty($error_message)) { ?>	
<div class="error-message"><?php if(isset($error_message)) echo $error_message; ?></div>
<?php } ?>

First Name
<input type="text" class="demoInputBox" name="fname" value="<?php if(isset($_POST['fname'])) echo $_POST['fname']; ?>" required><br><br>
Last Name
<input type="text" class="demoInputBox" name="lname" value="<?php if(isset($_POST['lname'])) echo $_POST['lname']; ?>" required><br><br>Contact
<input type="number" class="demoInputBox" name="contact" value="<?php if(isset($_POST['contact'])) echo $_POST['contact']; ?>" required><br><br>
Email
<input type="email" class="demoInputBox" name="email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>" required><br><br>
Password
<input type="password" class="demoInputBox" name="password" value="<?php if(isset($_POST['password'])) echo $_POST['password']; ?>" required><br><br>
Confirm Password
<input type="password" class="demoInputBox" name="cpassword" value="<?php if(isset($_POST['cpassword'])) echo $_POST['cpassword']; ?>" required><br><br>
<input type="submit" name="register-user" value="Register" class="btnRegister" required>
</form>
</div>
</bod/>
</html>
